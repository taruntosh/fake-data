import random
print(random.randrange(100,1000,100))